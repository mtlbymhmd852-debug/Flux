#!/data/data/com.termux/files/usr/bin/bash
# FLUX on this phone: starts the server, opens a free tunnel, and publishes the tunnel's current address
# (signed) so the fixed web page always finds it - even after the tunnel link changes.
cd "$(dirname "$0")"
export ADMIN_PASSWORD="$(cat admin-password.txt)"
export PORT=3001
termux-wake-lock 2>/dev/null
check() { curl -s -m 2 http://127.0.0.1:$PORT/api/health | grep -q ok; }
if ! check; then
  nohup node --no-warnings server.mjs > server.log 2>&1 &
  for i in $(seq 1 40); do
    check && break
    sleep 1
  done
fi
check || { echo "سرور بالا نیامد:"; cat server.log; exit 1; }
[ -f ~/.ssh/id_ed25519 ] || ssh-keygen -q -t ed25519 -N "" -f ~/.ssh/id_ed25519
node pointer.mjs init > /dev/null
echo "✅ سرور روشن است."
while true; do
  pkill ssh 2>/dev/null
  : > tunnel.log
  ssh -p 443 -o BatchMode=yes -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null -o ServerAliveInterval=15 -o ServerAliveCountMax=3 -R0:127.0.0.1:$PORT free.pinggy.io > tunnel.log 2>&1 &
  SSHPID=$!
  urls=""
  for i in $(seq 1 45); do
    urls="$( (grep -oE 'https://[a-z0-9.-]+\.pinggy-free\.link' tunnel.log | sort -u; grep -oE 'https://[a-z0-9.-]+\.pinggy\.(net|link)' tunnel.log | grep -v 'pinggy-free' | sort -u) | tr '\n' ' ')"
    [ -n "${urls// /}" ] && break
    kill -0 $SSHPID 2>/dev/null || break
    sleep 1
  done
  if [ -n "${urls// /}" ]; then
    echo "🔗 آدرس فعلی سرور: $urls"
    if node pointer.mjs publish $urls > /dev/null; then echo "📡 آدرس منتشر شد."; else echo "⚠️ انتشار آدرس نشد (اینترنت/فیلترشکن را چک کنید)."; fi
    last=$(date +%s)
    while kill -0 $SSHPID 2>/dev/null; do
      sleep 5
      if [ $(( $(date +%s) - last )) -ge 600 ]; then node pointer.mjs publish $urls > /dev/null 2>&1; last=$(date +%s); fi
    done
  fi
  echo "تونل قطع شد؛ ۳ ثانیه دیگر دوباره وصل می‌شود…"
  sleep 3
done
