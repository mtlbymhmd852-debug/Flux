#!/data/data/com.termux/files/usr/bin/bash
# Creates the folder you upload to GitHub Pages (the fixed address of the app).
cd "$(dirname "$0")"
OUT="$HOME/storage/downloads/FLUX-site"
rm -rf "$OUT"
node pointer.mjs init > /dev/null
node pointer.mjs site "$OUT" && echo "✅ پوشهٔ آماده شد: Download/FLUX-site (همهٔ فایل‌های داخلش را در GitHub آپلود کنید)"
ls "$OUT"
