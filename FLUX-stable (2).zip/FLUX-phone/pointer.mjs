// Publishes the server's current public address so the fixed web page can find it again after the link changes.
// The message is signed with a private key that never leaves this phone; the matching public key is built into
// the web page, so nobody else can send people to a different server.
//   node pointer.mjs init                 create the key + topic (first time only)
//   node pointer.mjs publish URL [URL..]  sign and publish the current address(es)
//   node pointer.mjs site OUTDIR          write the files to upload to the fixed web page
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const dir = path.dirname(fileURLToPath(import.meta.url));
const KEYFILE = path.join(dir, 'pointer-key.json');
const NTFY = (process.env.NTFY_BASE || 'https://ntfy.sh').replace(/\/+$/, '');
const subtle = globalThis.crypto.subtle;
const ECDSA = { name: 'ECDSA', namedCurve: 'P-256' };

async function ensureKey() {
  if (fs.existsSync(KEYFILE)) return JSON.parse(fs.readFileSync(KEYFILE, 'utf8'));
  const pair = await subtle.generateKey(ECDSA, true, ['sign', 'verify']);
  const topic = 'flux-' + Buffer.from(globalThis.crypto.getRandomValues(new Uint8Array(12))).toString('hex');
  const record = { topic, priv: await subtle.exportKey('jwk', pair.privateKey), pub: await subtle.exportKey('jwk', pair.publicKey) };
  fs.writeFileSync(KEYFILE, JSON.stringify(record), { mode: 0o600 });
  return record;
}

async function publish(urls) {
  const k = await ensureKey();
  const t = Math.floor(Date.now() / 1000);
  const key = await subtle.importKey('jwk', k.priv, ECDSA, false, ['sign']);
  const sig = await subtle.sign({ name: 'ECDSA', hash: 'SHA-256' }, key, new TextEncoder().encode(`${t}|${urls.join(',')}`));
  const response = await fetch(`${NTFY}/${k.topic}`, { method: 'POST', body: JSON.stringify({ u: urls, t, s: Buffer.from(sig).toString('base64') }) });
  if (!response.ok) throw new Error('publish failed: ' + response.status);
}

async function site(out) {
  const k = await ensureKey();
  const web = path.join(dir, 'web');
  fs.mkdirSync(out, { recursive: true });
  for (const name of fs.readdirSync(web)) {
    let data = fs.readFileSync(path.join(web, name));
    if (name === 'index.html') {
      const config = { pointer: { topic: k.topic, base: NTFY, key: k.pub } };
      const html = data.toString('utf8');
      if (!html.includes('window.FLUX_CONFIG=null;')) throw new Error('index.html has no config slot');
      data = Buffer.from(html.replace('window.FLUX_CONFIG=null;', () => 'window.FLUX_CONFIG=' + JSON.stringify(config) + ';'));
    }
    fs.writeFileSync(path.join(out, name), data);
  }
  fs.writeFileSync(path.join(out, '.nojekyll'), '');
}

const [command, ...args] = process.argv.slice(2);
try {
  if (command === 'init') { await ensureKey(); console.log('ok'); }
  else if (command === 'publish' && args.length) { await publish(args); console.log('published'); }
  else if (command === 'site' && args[0]) { await site(args[0]); console.log('site written to ' + args[0]); }
  else { console.error('usage: pointer.mjs init | publish URL.. | site OUTDIR'); process.exit(2); }
} catch (error) { console.error(String(error.message || error)); process.exit(1); }
