#!/data/data/com.termux/files/usr/bin/bash
pkg update -y && pkg upgrade -y
pkg install -y nodejs openssh curl
node -v
chmod +x go.sh site.sh
echo "✅ نصب تمام شد."
